Contributing
------------

Our project uses the standard GitHub pull request process for code review
and integration. Please check our [development][Development] guide for more
details on developing and contributing to the project. The GitHub issue
tracker can be used to report bugs, make feature requests, etc.

Our [wiki][Wiki] is used to document features, flesh out designs and host other
documentation. Our API is documented using Doxygen with updated
documentation generated nightly. We have several [mailing lists][MailingLists]
to coordinate development and to provide support.

  [Development]: http://wiki.openchemistry.org/Development "Development guide"
  [Wiki]: http://wiki.openchemistry.org/ "Open Chemistry wiki"
  [Doxygen]: http://doc.openchemistry.org/avogadrolibs/api/ "API documentation"
  [MailingLists]: http://openchemistry.org/mailing-lists "Mailing Lists"
